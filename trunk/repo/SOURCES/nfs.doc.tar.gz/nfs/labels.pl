# LaTeX2HTML 98.2 beta6 (August 14th, 1998)
# Associate labels original text with physical files.


$key = q/linux/;
$external_labels{$key} = "$URL/" . q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nfsv2/;
$external_labels{$key} = "$URL/" . q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/solaris/;
$external_labels{$key} = "$URL/" . q|node21.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 98.2 beta6 (August 14th, 1998)
# labels from external_latex_labels array.


$key = q/linux/;
$external_latex_labels{$key} = q|B|; 
$noresave{$key} = "$nosave";

$key = q/solaris/;
$external_latex_labels{$key} = q|A|; 
$noresave{$key} = "$nosave";

1;

