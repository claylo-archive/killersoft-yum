# LaTeX2HTML 98.2 beta6 (August 14th, 1998)
# Associate internals original text with physical files.


$key = q/linux/;
$ref_files{$key} = "$dir".q|node24.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_nfsv2/;
$ref_files{$key} = "$dir".q|node20.html|; 
$noresave{$key} = "$nosave";

$key = q/solaris/;
$ref_files{$key} = "$dir".q|node21.html|; 
$noresave{$key} = "$nosave";

1;

